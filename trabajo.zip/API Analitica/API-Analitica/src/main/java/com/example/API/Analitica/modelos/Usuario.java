package com.example.API.Analitica.modelos;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "usuarios")


public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer Id;

    @Column(length = 50, nullable = false)
    private String nombre;


    @Column(length = 10, nullable = false)
    private String contraseña;



    private LocalDate fechaNacimiento;


    public Usuario( ) {
    }

    public Usuario(String nombre, Integer id, String contraseña, LocalDate fechaNacimiento) {
        this.nombre = nombre;
        this.Id = id;
        this.contraseña = contraseña;
        this.fechaNacimiento = fechaNacimiento;
    }


    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        this.Id = id;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
