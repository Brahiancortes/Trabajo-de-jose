package com.example.API.Analitica.servicios;


import com.example.API.Analitica.modelos.Usuario;
import com.example.API.Analitica.repositorio.IUsuarioRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioServicio {

    protected final IUsuarioRepositorio repositorio;

    public UsuarioServicio(IUsuarioRepositorio repositorio) {
        this.repositorio = repositorio;
    }

    //guardar
    public boolean guardarUsuario(Usuario datos)throws Exception{

        try{
            this.repositorio.save(datos);
            return true;

        } catch (Exception error) {
            throw new Exception(error.getMessage());

        }

    }


    //buscarTodos
    public List<Usuario> buscarUsuarios()throws Exception{
        try {

            return this.repositorio.findAll();
        } catch (Exception error) {
                throw new Exception(error.getMessage());

        }
    }

}
