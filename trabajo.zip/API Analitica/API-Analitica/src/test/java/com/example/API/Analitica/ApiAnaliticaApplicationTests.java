package com.example.API.Analitica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiAnaliticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
