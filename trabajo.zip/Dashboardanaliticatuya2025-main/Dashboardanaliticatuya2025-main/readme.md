# Dashboard de analisis de datos tiendas chevignion

## 🤖Proyecto 2 de la materia nuevas tecnologias, grupo empresarial tuya