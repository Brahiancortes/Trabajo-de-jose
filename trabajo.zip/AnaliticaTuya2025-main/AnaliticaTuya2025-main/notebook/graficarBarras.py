import matplotlib.pyplot as plt
import os
import re

def generarBarra(tablaOrdenada, columnaX, columnaY, titulo):
    colores = [
        "#8258C7",
        "#58C783",
        "#80C758",
        "#C7C758",
        "#C7585A"
    ]

    # Crear carpeta si no existe
    carpeta_graficas = "graficas"
    os.makedirs(carpeta_graficas, exist_ok=True)

    # Agrupar datos
    agrupacionDatos = tablaOrdenada.groupby(columnaX)[columnaY].sum()

    # Crear figura
    plt.figure(figsize=(10, 5))
    plt.bar(agrupacionDatos.index, agrupacionDatos.values, color=colores[:len(agrupacionDatos)])
    plt.title(titulo)
    plt.xlabel(columnaX.capitalize())
    plt.ylabel(columnaY.capitalize())
    plt.tight_layout()

    # 🔠 Reemplazar símbolos por palabras legibles
    reemplazos = {
        '>': 'mayor_que',
        '<': 'menor_que',
        '=': 'igual_a',
        ':': '_',
        '"': '',
        '/': '_',
        '\\': '_',
        '|': '_',
        '?': '',
        '*': ''
    }

    nombre_archivo = titulo
    for simbolo, reemplazo in reemplazos.items():
        nombre_archivo = nombre_archivo.replace(simbolo, reemplazo)

    nombre_archivo = nombre_archivo.replace(" ", "_").lower() + ".png"
    ruta_guardado = os.path.join(carpeta_graficas, nombre_archivo)

    # Guardar la imagen
    plt.savefig(ruta_guardado, bbox_inches='tight')
    plt.close()  # Cerrar figura para liberar memoria
    print(f"✅ Gráfica guardada en: {ruta_guardado}")
