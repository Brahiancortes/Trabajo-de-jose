package com.example.API.Analitica.modelos;

import static org.junit.jupiter.api.Assertions.*;
class UsuarioTest {

}