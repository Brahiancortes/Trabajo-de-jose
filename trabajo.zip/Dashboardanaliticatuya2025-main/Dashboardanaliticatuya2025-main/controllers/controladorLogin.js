import { buscarUsuarios, guardarUsuario } from "../services/servicioUsuario.js";

// capturar los datos del formulario
let cajaNombreUsuario = document.getElementById("nombre");
let cajaContraseñaUsuario = document.getElementById("contraseña");
let cajaFechaNacimiento = document.getElementById("fechaNacimiento"); // 🔹 nuevo campo
let botonFormulario = document.getElementById("boton");

botonFormulario.addEventListener("click", (evento) => {
    evento.preventDefault();

    // crear el objeto de datos
    let datos = {
        nombre: cajaNombreUsuario.value,
        contraseña: cajaContraseñaUsuario.value,
        fechaNacimiento: cajaFechaNacimiento.value // 🔹 se envía como string ISO (YYYY-MM-DD)
    };

    guardarUsuario(datos)
        .then(function (respuesta) {
            if (respuesta) {
                Swal.fire({
                    title: "Buen trabajo!",
                    text: "Te has registrado con éxito",
                    icon: "success"
                });
                // limpiar formulario
                cajaNombreUsuario.value = "";
                cajaContraseñaUsuario.value = "";
                cajaFechaNacimiento.value = "";
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Fallamos",
                    text: "Algo salió mal en tu registro"
                });
            }
        })
        .catch((error) => {
            console.error("Error al guardar usuario:", error);
            Swal.fire({
                icon: "error",
                title: "Error del servidor",
                text: "No pudimos conectar con el backend"
            });
        });
});


//llamar al api para guardar

//mostrar mensaje de exito si se guardo el usuario con exito