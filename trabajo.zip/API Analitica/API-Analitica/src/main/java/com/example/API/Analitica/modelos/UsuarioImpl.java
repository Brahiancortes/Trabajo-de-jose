package com.example.API.Analitica.modelos;

public class UsuarioImpl extends Usuario {
    public UsuarioImpl() {
    }
}
